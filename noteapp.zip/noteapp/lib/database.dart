// import 'package:hive_flutter/hive_flutter.dart';

// class noteDatabase{

//  List<Notes> sampleNotes =[];

//   final _myBox = Hive.box('mybox');





// }
// class Notes {
//   int id;
//   String title;
//   String content;
//   DateTime modifieTime;

//   Notes(
//       {required this.id,
//       required this.title,
//       required this.content,
//       required this.modifieTime});
// }

// List<Notes> filteredNotes = [];