// import 'dart:convert';
// import 'dart:math';

// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:noteapp/colors.dart';
// import 'package:noteapp/notes.dart';
// import 'package:noteapp/screens/edit.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// class NotesScreen extends StatefulWidget {
//   @override
//   _NotesScreenState createState() => _NotesScreenState();
// }

// class _NotesScreenState extends State<NotesScreen> {
//   List<Notes> _notes = [];

//   @override
//   void initState() {
//     super.initState();
//     _loadNotes();
//   }

//   Future<void> _loadNotes() async {
//     final prefs = await SharedPreferences.getInstance();
//     final notesList = prefs.getStringList('notes') ?? [];

//     setState(() {
//       _notes = notesList.map((noteJson) {
//         final noteData = jsonDecode(noteJson);
//         return Notes(
//           id: _notes.length + 1,
//           title: noteData['title'],
//           content: noteData['content'],
//           modifieTime: DateTime.now(),
//         );
//       }).toList();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Notes'),
//       ),
//       body: ListView.builder(
//         itemCount: _notes.length,
//         itemBuilder: (context, index) {
//           final note = _notes[index];
//           return ListTile(
//             title: Text(note.title),
//             subtitle: Text(note.content),
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => EditScreen(note: note),
//                 ),
//               ).then((result) {
//                 if (result != null) {
//                   final updatedNote = Notes(
//                     id: note.id,
//                     title: result[0],
//                     content: result[1],
//                     modifieTime: DateTime.now(),
//                   );
//                   setState(() {
//                     _notes[index] = updatedNote;
//                   });
//                 }
//               });
//             },
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//               builder: (context) => EditScreen(),
//             ),
//           ).then((result) {
//             if (result != null) {
//               final newNote = Notes(
//                 id: _notes.length + 1,
//                 title: result[0],
//                 content: result[1],
//                 modifieTime: DateTime.now(),
//               );
//               setState(() {
//                 _notes.add(newNote);
//               });
//             }
//           });
//         },
//         child: Icon(Icons.add),
//       ),
//     );
//   }
// }
