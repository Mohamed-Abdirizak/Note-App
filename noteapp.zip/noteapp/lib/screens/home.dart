import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:noteapp/colors.dart';
import 'package:noteapp/notes.dart';
import 'package:noteapp/screens/edit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

class HomeScreen extends StatefulWidget {
  // const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Notes> filteredNotes = [];
  bool sorted = false;
  // List<String> _textFieldValues = [];

  /// list ............. of data

  @override
  void initState() {
    super.initState();
    filteredNotes = sampleNotes;
  }

// deleting the notes... start
  void deleteNotes(int index) {
    setState(() {
      filteredNotes.removeAt(index);
    });
  }
  // deleting the notes... end

//// sorting to date start................
  List<Notes> sortNoteByModifiedTime(List<Notes> notes) {
    if (sorted) {
      notes.sort((a, b) => a.modifieTime.compareTo(b.modifieTime));
    } else {
      notes.sort((b, a) => a.modifieTime.compareTo(b.modifieTime));
    }
    sorted = !sorted;

    return notes;
  }
//// sorting to date end................

///// get random color: start
  getRandomColor() {
    Random random = Random();
    return backgorundcolor[random.nextInt(backgorundcolor.length)];
  }
  ///// get random color: end

  /// search notes..start....
  onSearchTextChanged(String searchText) {
    setState(() {
      filteredNotes = sampleNotes
          .where((note) =>
              note.content.toLowerCase().contains(searchText.toLowerCase()) ||
              note.title.toLowerCase().contains(searchText.toLowerCase()))
          .toList();
    });
  }

  /// search notes..end....

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      body: Padding(
        // padding: EdgeInsets.fromLTRB(16, 80, 16, 0),
        padding: EdgeInsets.only(left: 1.6.w, top: 8.h, right: 1.6.w),
        child: Column(
          children: [
            Row(
              /////////// start:  rowga hore: ee kakooban Notes(text) iyo icon ka sorting....ka
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Notes",
                  style: TextStyle(fontSize: 25.sp, color: Colors.white),
                ),
                Container(
                  padding: EdgeInsets.only(
                      top: 1.h, bottom: 1.h, left: 2.w, right: 2.w),
                  decoration: BoxDecoration(
                      color: Colors.grey[600],
                      borderRadius: BorderRadius.circular(12)),
                  child: IconButton(
                      onPressed: () => {
                            setState(() {
                              filteredNotes =
                                  sortNoteByModifiedTime((filteredNotes));
                            }),
                          },
                      icon: Icon(
                        Icons.sort,
                        color: Colors.white,
                        size: 40,
                      )),
                )
              ],
            ),
            /////////// end:  rowga hore: ee kakooban Notes(text) iyo icon ka sorting....ka

            SizedBox(
              height: 3.h,
            ),
            ////////////////// search bar starts here...
            TextField(
              onChanged: onSearchTextChanged,
              style: TextStyle(fontSize: 10.sp, color: Colors.white),
              decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                  hintText: "Search notes...",
                  hintStyle: const TextStyle(color: Colors.grey),
                  prefixIcon: const Icon(
                    Icons.search,
                    color: Colors.grey,
                  ),
                  fillColor: Colors.grey.shade800,
                  filled: true,
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: const BorderSide(color: Colors.transparent)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: const BorderSide(color: Colors.transparent))),
            ),
            ////////////// search bar ends here..

            Expanded(

                ////// notes list.. start here...
                child: ListView.builder(
              itemCount: filteredNotes.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.only(bottom: 2.h),
                  color: getRandomColor(),
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: 1.h, bottom: 1.h, left: 1.w, right: 1.w),
                    child: ListTile(
                      onTap: () async {
                        //////////// start:  open edit screen when the note tapped.
                        final result = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    EditScreen(note: filteredNotes[index])));

                        if (result != null) {
                          setState(() {
                            int originalIndex =
                                sampleNotes.indexOf(filteredNotes[index]);
                            sampleNotes[originalIndex] = Notes(
                                id: sampleNotes[originalIndex].id,
                                title: result[0],
                                content: result[1],
                                modifieTime: DateTime.now());
                            filteredNotes[index] = Notes(
                                id: sampleNotes[originalIndex].id,
                                title: result[0],
                                content: result[1],
                                modifieTime: DateTime.now());
                          });
                        }
                        //////////// end:  open edit screen when the note tapped.
                      },
                      title: RichText(
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          text: TextSpan(
                              text: '${filteredNotes[index].title} \n',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10.sp,
                                  height: 0.2.h),
                              children: [
                                TextSpan(
                                    text: '${filteredNotes[index].content}',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 8.sp,
                                        height: 0.1.h))
                              ])),
                      subtitle: Padding(
                        padding: EdgeInsets.only(top: 1.h),
                        child: Text(
                          '${DateFormat('EEE MMM d, yyyy h:mm a').format(filteredNotes[index].modifieTime)}',
                          style: TextStyle(
                              fontSize: 7.sp,
                              fontStyle: FontStyle.italic,
                              color: Colors.grey.shade800),
                        ),
                      ),
                      trailing: IconButton(
                          onPressed: () async {
                            ///////////// show dailong for deleting notes

                            final result =
                                await confirmationOfDialongBox(context);
                            if (result != null && result) {
                              deleteNotes(index);
                            }

                            ///end: show dialg for deleting notes
                          },
                          icon: Icon(Icons.delete)),
                    ),
                  ),
                );
              },
            )),
            //////// notes list.. ends here...
          ],
        ),
      ),

      ////////////add button....................start...........
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => const EditScreen()));
          if (result != null) {
            setState(() {
              sampleNotes.add(Notes(
                  id: sampleNotes.length,
                  title: result[0],
                  content: result[1],
                  modifieTime: DateTime.now()));
              filteredNotes = sampleNotes;
            });
          }
          ;
        },
        elevation: 10,
        backgroundColor: Colors.grey,
        child: Icon(Icons.add),
      ),
      /////////////////////   ////////////add button....................end...........
    );
  }

////////////////// function..................
  Future<dynamic> confirmationOfDialongBox(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Colors.grey.shade900,
            icon: Icon(
              Icons.info,
              color: Colors.grey,
            ),
            title: Text(
              "Are you sure you want to delete?",
              style: TextStyle(color: Colors.white),
            ),
            content: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    onPressed: () {
                      Navigator.pop(context, true);
                    },
                    child: SizedBox(
                      width: 6.w,
                      child: Text(
                        "Yes",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: () {
                      Navigator.pop(context, false);
                    },
                    child: SizedBox(
                      width: 6.w,
                      child: Text(
                        "No",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  )
                ]),
          );
        });
  }
}
