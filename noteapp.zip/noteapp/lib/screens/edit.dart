import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:noteapp/notes.dart';
import 'package:sizer/sizer.dart';

class EditScreen extends StatefulWidget {
  final Notes? note;
  const EditScreen({super.key, this.note});

  @override
  State<EditScreen> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  TextEditingController _topicController = TextEditingController();
  TextEditingController _contentController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (widget.note != null) {
      _topicController = TextEditingController(text: widget.note!.title);
      _contentController = TextEditingController(text: widget.note!.content);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      body: Padding(
        // padding: EdgeInsets.fromLTRB(16, 80, 16, 0),
        // padding: EdgeInsets.only(left: 16, top: 80, right: 16),
        padding: EdgeInsets.only(left: 1.6.w, top: 8.h, right: 1.6.w),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                    padding: EdgeInsets.only(bottom: 0.7.h),
                    decoration: BoxDecoration(
                        color: Colors.grey[400],
                        borderRadius: BorderRadius.circular(12)),
                    child: IconButton(
                      onPressed: () => {Navigator.pop(context)},
                      icon: Icon(
                        Icons.arrow_back_ios,
                        size: 40,
                      ),
                    )),
              ],
            ),
            Expanded(
                child: ListView(
              children: [
                TextField(
                  controller: _topicController,
                  style: TextStyle(color: Colors.white, fontSize: 20.sp),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "write title",
                      hintStyle:
                          TextStyle(color: Colors.grey, fontSize: 20.sp)),
                ),
                TextField(
                  maxLines: null,
                  controller: _contentController,
                  style: TextStyle(color: Colors.white, fontSize: 15.sp),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "type something here....",
                      hintStyle:
                          TextStyle(color: Colors.grey, fontSize: 15.sp)),
                )
              ],
            )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pop(
              context, [_topicController.text, _contentController.text]);
        },
        elevation: 10,
        backgroundColor: Colors.grey.shade800,
        child: Icon(
          Icons.save,
          // size: 50,
        ),
      ),
    );
  }
}
