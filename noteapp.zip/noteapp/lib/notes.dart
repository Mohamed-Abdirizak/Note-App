class Notes {
  int id;
  String title;
  String content;
  DateTime modifieTime;

  Notes(
      {required this.id,
      required this.title,
      required this.content,
      required this.modifieTime});
}
List<Notes> sampleNotes =[];

// List<Notes> sampleNotes = [
//   Notes(
//     id: 0,
//     title: "Jamacada aaad",
//     content:
//         "Xiisada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo, waana muhiiim.",
//     modifieTime: DateTime(2023, 1, 1, 34, 6),
//   ),
//   Notes(
//     id: 1,
//     title: "Bareefadka aad",
//     content:
//         "Xiisada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo, waana muhiiim  hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo,ada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo,ada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo,ada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo,ada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaaminada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo, casud waxaa saaran 5dadrajo,",
//     modifieTime: DateTime(2023, 1, 1, 34, 6),
//   ),
//   Notes(
//     id: 2,
//     title: "Xiisada bixi",
//     content:
//         "Xiisada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo, waana muhiiim.",
//     modifieTime: DateTime(2021, 1, 1, 34, 6),
//   ),
//   Notes(
//     id: 3,
//     title: "Jamacada aaad",
//     content:
//         "Xiisada hore assignment waaye lasoco, ha isku hilmaamin casud waxaa saaran 5dadrajo, waana muhiiim.",
//     modifieTime: DateTime(2025, 1, 1, 34, 6),
//   ),
// ];
